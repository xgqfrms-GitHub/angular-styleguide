interface AuthConfiguration {
    clientID: string,
    domain: string
}

export const myConfig: AuthConfiguration = {
    clientID: 'PlP5AbQeOOJ3RWNynrI27AJeb7U5H2dv',
    domain: 'xgqfrms.auth0.com'
};
